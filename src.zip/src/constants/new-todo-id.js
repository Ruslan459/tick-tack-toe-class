export const NEW_TODO_ID = 'NEW_TODO_ID';
